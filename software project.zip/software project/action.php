<?php

require_once("config.php");

if(isset($_POST['uname']))
{
   $name=$_POST['uname'];
   $email=$_POST['email'];
   $pass=$_POST['password'];
   $password=sha1($_POST['password']);
   $department=$_POST['department'];
   $designation=$_POST['designation'];

    if($_FILES['image']['name'])
    {

      $file=$_FILES['image']['name'];
      $path="images/".$file;
      $tmp=$_FILES['image']['tmp_name'];
      move_uploaded_file($tmp, $path);
    }




   $query="INSERT INTO info VALUES('$name','$email','$password','$department','$designation')";
   $send=mysqli_query($connection,$query);


   if($send)
   {





          require 'mail/PHPMailerAutoload.php';
          require_once('mail/class.phpmailer.php');





            $mail = new PHPMailer;

            //$mail->SMTPDebug = 2;                               // Enable verbose debug output
            $mail->SMTPOptions = array(
                     'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
             )
            );

            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'ucoder10@gmail.com';                 // SMTP username
            $ms=str_rot13('hygvzngrora');
            $mail->Password = $ms;                           // SMTP password
            $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587;                                    // TCP port to connect to


                // Add a recipient
            //$mail->addAddress('ellen@example.com');               // Name is optional
            //$mail->addReplyTo('info@example.com', 'Information');
            //$mail->addCC('cc@example.com');
            //$mail->addBCC('bcc@example.com');

            //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
            //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
            $mail->isHTML(true);                                  // Set email format to HTML

            //$mail->Subject = 'RUET OJ Contest Alert Test';
            //$mail->Body    = 'This is the Test Message <b>in bold!</b>';
            //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';





            $mail->setFrom('ucoder10@gmail.com', 'MekTek Web Class');




               //echo "$em";

               $mail->addAddress($email,'User');

               $mail->Subject = 'MekTek Web Class';
               $mail->Body    = 'Hi '.$name.' , Thank You For Your Registration.<br> Your Username : '.$name.'<br> Password : '.$pass.'<br>';
                $mail->AltBody = 'Hi '.$name.' , Thank You For Your Registration.<br> Your Username : '.$name.'<br> Password : '.$pass.'<br>';






             if(!$mail->send()) {
                echo 'Message could not be sent.';
                echo 'Mailer Error: ' . $mail->ErrorInfo;
               } else {
                echo 'Message has been sent';
               }
               $mail->ClearAddresses();










       header("Location:login.php");
    }

   else {
      header("Location:registration.php?value=fail");
   }
}

 ?>
