<?php

  require_once("config.php");
  session_start();

    if(isset($_SESSION['un']))
    {
    	$name=$_SESSION['un'];
    }
    else
    {
    	header("Location:login.php");
    }


    $sql="SELECT * from info where name='$name'";
    $send=mysqli_query($connection,$sql);
    $row=mysqli_fetch_array($send);




?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <style media="screen">
      .r
      {margin-left: 100px;}
    </style>
  </head>
  <body>

  </body>
</html>
<fieldset>
<legend>Admit Card</legend>

<div class="r">
<b> <h3>Admit Card </h3></b>
  <img src="<?php echo "$row[image]";  ?>" width="200px"; height="200px"><br><br>
<b>Name : <?php echo "$row[name]";  ?></b><br><br>
<b>HSC Roll: <?php echo "$row[email]";  ?></b><br><br>
<b> Examinatoin Date:23july</b><br><br>
<b> Admissoin Roll:1610027</b><br><br>


<a href="profile.php" download="admit.pdf" > download</a></div>

</fieldset>
