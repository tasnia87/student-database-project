<?php

require_once("config.php");

 ?>

 <!DOCTYPE html>
 <html>
   <head>
     <meta charset="utf-8">
     <title>Registration</title>
     <link rel="stylesheet" type="text/css" href="style.css">
     <style media="screen">

    .header
    {
      text-align: center;
      background-color: #1a3333;
      color: white;
      top: 0px;
      width: 100%;
      padding: 5px; }
      .d
      {text-align: center;}
  </style>

   </head>

   <body>
     <div class="header">
       <h1>Registration</h1></div>


     <form class="" action="action.php" method="post" enctype="multipart/form-data">
       <table style="margin-left:500px;">
     <tr><td>Name:</td><td><input type="text" name="uname" </td></tr>
     <tr><td>Email:</td><td><input type="text" name="email" </td></tr>



     <tr><td>Department:</td><td><input type="text" name="department" </td></tr>
     <tr><td>Designation:</td><td><input type="text" name="designation" </td></tr>
     <tr><td>Password:</td><td><input type="password" name="password" ><br></td></tr>
     <tr><td><input type="submit" value="Submit"></td></tr>

   </table>
     </form>
</div>
     <?php

      if(isset($_GET['value']))
      {
         echo "Username is already existed. Please try with different one";
      }


      ?>
   </body>
 </html>
