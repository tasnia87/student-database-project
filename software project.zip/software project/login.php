<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <style>
    .header
    {
      text-align: center;
      background-color: #1a3333;
      color: white;
      top: 0px;
      width: 100%;
      padding: 5px; }
      .d
      {margin-left: 500px;
      margin-top: 50px;}

  </style>

  </head>
  <body>
    <div class="header" style="length:50px"><h3> Admin Login</h3></div>
    <form class="" action="process.php" method="post"enctype="multipart/form-data">
      <div class="d">
    Name:<input type="text" name="name"><br>
  Password:<input type="password" name="password"><br>

    <input type="submit" value="Submit"></div>
  </form>
  </body>
</html>
