<?php

$errors=array();
$host="localhost";
$user="root";
$password="";
$db="ruet";

$connection=mysqli_connect($host,$user,$password,$db);
//if the registration button is clicked
if (isset($_POST['ruet']))
$name=mysql_real_escape_string($_POST['name']);
$department=mysql_real_escape_string($_POST['department']);
$email=mysql_real_escape_string($_POST['email']);
$username=mysql_real_escape_string($_POST['username']);
$password=mysql_real_escape_string($_POST['password']);


//ensure that form is fill up properly
if(empty($username))
{
array_push($errors,"Username is required");
}
if(empty($department))
{
array_push($errors,"Department is required");
}
if(empty($designation))
{
array_push($errors,"Designation is required");
}
if(empty($email))
{
array_push($errors,"Email is required");
}
if(empty($password_1))
{
array_push($errors,"Password is required");

}


if(count($errors==0))
{
  $sql="INSERT INTO students(name, department, email, username, password) VALUES ('$name','$department','$email','$username','$password')";

  mysqli_query($db,$sql);
}
?>
