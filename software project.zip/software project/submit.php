<?php

$url=$_POST['link'];


 ?>

 <input type="text" name="" size="50" value="<?php echo $url; ?> "/>
